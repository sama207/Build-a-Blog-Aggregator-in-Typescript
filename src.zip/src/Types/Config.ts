export type Config = {
    dbUrl: string,
    currentUserName?: string
}